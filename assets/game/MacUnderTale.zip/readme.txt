-- Mac Undertale DEMO v1.00 --

-- Please open instruction.html for more credits and information about the game. --

-- Note: The game can be played one-handed or on European keyboards with the following keys: --

ENTER = Z
SHIFT = X
CTRL = C


FONTS --

-- Main font - 8Bitoperator by Jayvee D. Enaguas (Grand Chaos) --
-- Damage font - Hachicro by FluckyFrog --
-- Various bitmap fonts by auntie pixelante --


-- Mac port by Leon Arnott. --
-- Special thanks to Flashygoodness for the keyboard code. --

